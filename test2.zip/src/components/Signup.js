//Signup.js

import React, { useEffect, useState } from "react"
import axios from "axios"
import { useNavigate, Link } from "react-router-dom"
import "../css/Signup.css"
import i2 from "../assets/lavender.jpg";


function Login({ setIsUserLoggedIn }) {
    const history=useNavigate();
    const [educationLevel,setEducationLevel]=useState('');
    const [username,setUsername]=useState('');
    const [fullName, setFullName] = useState('');
    const [email, setEmail] = useState('');
    const [password,setPassword]=useState('')
    const [club,setClubname]=useState('')
    const [year, setYear] = useState('');
    const [course, setCourse] = useState('');
    const [contactNumber, setContactNumber] = useState('');
    const [message1, setMessage1] = useState(null); 
    // const [message2, setMessage2] = useState(null); 
    const [usernamePlaceholder, setUsernamePlaceholder] = useState( "Username/Register number" );
    const [yearPlaceholder, setYearPlaceholder] = useState("Year/Class");
    // const [initialEducationLevel, setInitialEducationLevel] = useState("");
    // const [initialUsername, setInitialUsername] = useState("");
    // const [initialYear, setInitialYear] = useState("");
    useEffect(() => {
        // If PG is selected, set club to M.Sc and disable the dropdown
        if (educationLevel === "PG") {
          setClubname("M.Sc");
          setCourse("M.Sc");
          setUsernamePlaceholder("PG Register Number");
          setYearPlaceholder("PG Year/Class");
        } else {
          setClubname(""); 
          setCourse("");
          setUsernamePlaceholder("UG Register Number");
          setYearPlaceholder("UG Year/Class");
        }
      }, [educationLevel]);

      const validateUsername = () => {
        const isValid =
          (educationLevel === "PG" &&
            /P\d{2}[M][G]\d{2}[S]{1}\d{6}/.test(username)) ||
          (educationLevel === "UG" && /U\d{2}[M][G]\d{2}[S]{1}\d{6}/.test(username));
    
        if (!isValid) {
            setMessage1(
                `please enter valid ${
                  educationLevel === "PG" ? " PG register " : " UG register "
                } number`
            );
          
        }
        else {
            setMessage1(null); // Clear the error message for a valid username
        }
      };

    
    async function submit(e){
        e.preventDefault();
        try{

            await axios.post("http://localhost:3000/Signup",{
                educationLevel,username,fullName,email,year,course,contactNumber,club,password,
            })
            .then(res=>{
                if(res.data=="exist"){
                    alert("User already exists")
                }
                else if(res.data=="notexist"){
                    // history("/home",{state:{id:email}})
                    setIsUserLoggedIn(true);
                    alert("Signup successful");
                    history("/")
                }
                // else if(res.data=="notallowed"){
                //     alert("Not valid Username enter again")
                // }
            })
            .catch(e=>{
                alert("wrong details")
                console.log(e);
            })

        }
        catch(e){
            console.log(e);

        }

    }

    
    


    return (
        <div className="signup-container">
            <h2 className="signup-text">SignUp</h2>
            <form action="POST" className="signup-form">
                <div className="form-group">
                    <label htmlFor="educationLevel">Education Level:</label>
                    <div className="radio-group">
                        <label>
                        <input
                            type="radio"
                            value="UG"
                            onChange={() => setEducationLevel("UG")}
                            checked={educationLevel === "UG"}
                            required
                            // id="educationLevel"
                        />UG
                        </label>
                        <label>
                        <input
                            type="radio"
                            value="PG"
                            onChange={() => setEducationLevel("PG")}
                            checked={educationLevel === "PG"}
                            required
                            // id="educationLevel"
                        />
                        PG
                        </label>
                    </div>
                </div>
                <div className="form-group">
                    <label htmlFor="username">Username/Register number:</label>
                    <input
                        type="text"
                        onChange={(e) => setUsername(e.target.value)}
                        onBlur={validateUsername}
                        placeholder={usernamePlaceholder}
                        required
                        id="username"
                    />
                </div>
                <div className="error-box"> 
                    {message1 && (
                            <div className={`message ${message1.includes("success") ? "success" : "error"}`}>
                            {message1}
                            
                            </div>
                    )}
                </div>
                <div className="form-group">
                    <label htmlFor="fullName">Full Name:</label>
                    <input type="text" onChange={(e) => setFullName(e.target.value)} placeholder="Full Name"  id="fullName" required />
                </div>

                <div className="form-group">
                    <label htmlFor="email">Email Address:</label>
                    <input type="email" onChange={(e) => setEmail(e.target.value)} placeholder="example@mail.com" id="email" />
                </div>

                <div className="form-group">
                    <label htmlFor="year">Year/Class:</label>
                    <select
                        onChange={(e) => setYear(e.target.value)}
                        value={year}
                        required
                        id="year"
                        
                    >
                        <option value="" disabled>
                            Select Year
                        </option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3" disabled={educationLevel === "PG"}>3</option>
                    </select>
                </div>
                
                <div className="form-group">
                    <label htmlFor="course">Course:</label>
                    <select
                        onChange={(e) => setCourse(e.target.value)}
                        value={course}
                        required
                        id="course"
                        disabled={educationLevel === "PG"}
                    >
                        <option value="" disabled>
                            Select Course
                        </option>
                        {/* <option value="MSc">M.Sc</option> */}
                        <option value="BSc">B.Sc</option>
                        <option value="BCom">B.Com</option>
                        <option value="BCA">B.C.A</option>
                        <option value="BA" >B.A</option>
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="contactNumber">Contact Number:</label>
                    <input type="number" onChange={(e) => setContactNumber(e.target.value)} placeholder="Contact Number" id="contactNumber"/>
                </div>

                <div className="form-group">
                    <label htmlFor="club">ClubName:</label>
                    <select onChange={(e) => setClubname(e.target.value)}
                     value={club}
                     required
                     id="club"
                     autoComplete="off" 
                     disabled={educationLevel === "PG"}
                   
                    >
                    <option value="" disabled>
                        Select Club
                    </option>
                    <option value="Arts Club">Arts Club</option>
                    <option value="NSS">NSS</option>
                    <option value="RedCross">Red Cross</option>
                    <option value="ITClub">IT Club</option>
                    <option value="ScienceClub">Science Club</option>
                    <option value="CommerceClub">Commerce Club</option>
                    <option value="NCCNavy">NCC Navy</option>
                    <option value="NCCArmy">NCC Army</option>
                    <option value="EcoClub">Eco Club</option>
                    <option value="RangerRovers">RangerRovers</option>
                    {/* {educationLevel !== "UG" && (
                    <option value="MSc" disabled={educationLevel === "UG"}>
                         M.Sc
                    </option>
            )} */}
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="password">Password :</label>
                    <input type="password" onChange={(e) => setPassword(e.target.value)} placeholder="Password" id="password" required />
                </div>

                <div className="form-group">
                    <input className="submit-button" type="submit" onClick={submit} />
                </div>
            </form>
            <br />
            <p>OR</p>
            <br />
            <Link to="/login">Login Page</Link>
        </div>
    )
}

export default Login